import { Component } from '@angular/core';
class ContactInfo {
    constructor(
        public description: string) { }
}
@Component({
    moduleId: module.id,
    selector: 'as-newcategory',
    template: require('./newcategory.component.html')
})
export class NewcategoryComponent {
    information = [
    ];
    myInfo = this.information[0];

    addInfo(newInfo: string) {
        if (newInfo) {
            this.information.push(new ContactInfo(newInfo));
        }
    }
}
