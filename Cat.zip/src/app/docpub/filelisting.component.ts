import { Component } from '@angular/core';
import { FileMetadataService } from './filemetadata.service';
import { FileMetadataListing } from './filemetadatalisting.model';
import { SubCategories } from './filemetadatalisting.model';
import { FileMetadata } from './filemetadata.model';

@Component({
    selector: 'as-filelisting',
    template: require('./filelisting.component.html')
})

export class FileListingComponent {
    public filemetadatalisting: FileMetadataListing[];
    public subcategory: SubCategories[];
    public fileMetadata: FileMetadata;
    public showNoRowsMessage: boolean;
    public showfilelisting: Boolean;
    public sorting: any;
    public columns: any[];
    public classCollapse: string;
    public parentClassCollapse: string;
    public expandAllCollapseAllButton: string;
    public subCategoryCount: number;
    constructor(private filemetadataService: FileMetadataService) {
        this.showNoRowsMessage = false;
        this.filemetadatalisting = [new FileMetadataListing(this.subcategory)];
        this.fileMetadata = new FileMetadata(new Date(), 0, 0, new Date().toDateString(), 1, ' ', ' ', ' ', 'HUM', new Date(), 3, 1);
        this.classCollapse = 'accordian-body collapse';
        this.parentClassCollapse = 'accordion-toggle collapsed';
        this.expandAllCollapseAllButton = 'fa fa-chevron-down';
        this.subCategoryCount = 0;
        this.columns = [
            {
                display: 'Document', // The text to display
                variable: 'displayName', // The name of the key that's apart of the data array                
                typehref: true
            },
            {
                display: 'Filename', // The text to display
                variable: 'fileName', // The name of the key that's apart of the data array
                typehref: false
            },
            {
                display: 'Size (MB)', // The text to display
                variable: 'FileSize', // The name of the key that's apart of the data array
                typehref: false
            },
            {
                display: 'Status', // The text to display
                variable: 'statusName', // The name of the key that's apart of the data array
                typehref: false
            },
            {
                display: 'Status Date', // The text to display
                variable: 'statusDate', // The name of the key that's apart of the data array
                typehref: false
            },
            {
                display: 'Downloaded', // The text to display
                variable: 'LastDownLoaded', // The name of the key that's apart of the data array
                typehref: false
            },
            {
                display: 'Expires', // The text to display
                variable: 'expirationDate', // The name of the key that's apart of the data array
                typehref: false
            },
            {
                display: 'Published By', // The text to display
                variable: 'UserId', // The name of the key that's apart of the data array
                typehref: false
            }
        ];
        this.sorting = {
            column: 'fileName', // to match the variable of one of the columns
            descending: false
        };
    }
    getFileMetadatalisting(planname: string) {
        console.log(this.showNoRowsMessage);
        this.showNoRowsMessage = false;
        this.filemetadataService.getFileMetadatalisting(planname).subscribe(res => this.populateFileListing(res.categories, true),
            err => this.populateFileListing(err, false));
    };
    populateFileListing(fileListingData: any, isSuccess: boolean) {
        this.filemetadatalisting = [];
        this.filemetadatalisting = fileListingData;
        this.showfilelisting = isSuccess ? true : false;
        this.showNoRowsMessage = !this.showfilelisting;
        console.log(this.showNoRowsMessage);
    };
    expandAll(changeClass: string) {
        console.log(changeClass);
        if (changeClass === 'accordion-toggle') {
            this.classCollapse = 'accordian-body collapse';
            this.parentClassCollapse = 'accordion-toggle collapsed';
            this.expandAllCollapseAllButton = 'fa fa-chevron-down';
        }
        else {
            this.classCollapse = 'accordian-body collapse in';
            this.parentClassCollapse = 'accordion-toggle';
            this.expandAllCollapseAllButton = 'fa fa-chevron-up';
        }
    }
    setSubCategoryCount(fileCount: number, count: number) {
        if (fileCount !== 0) {
            this.subCategoryCount = count + 1;
            return false;
        }
        else {
            return true;
        }
    }
    clearSubCategoryCount() {
        this.subCategoryCount = 0;
    }
    showOrHideCategory(searchString, categoryCount: number) {
        if (searchString !== '' && categoryCount === 0) {
            return true;
        }
        else {
            return false;
        }
    }
}
